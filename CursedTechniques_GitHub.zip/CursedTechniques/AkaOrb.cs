using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using StardewValley;
using System;

namespace CursedTechniques
{
    public class AkaOrb
    {
        // Orb'un oyuncuya göre pozisyonu
        private Vector2 offset;
        private float bobTimer = 0f;        // yukarı aşağı sallanma zamanlayıcısı
        private float bobAmount = 12f;      // sallanma yüksekliği (pixel)
        private float bobSpeed = 2.5f;      // sallanma hızı
        private float lifetime = 0f;
        private float maxLifetime = 999f;   // Silah elde tutulduğu sürece aktif

        // Öne doğru mesafe (oyuncunun önünde)
        private float forwardDistance = 80f;

        public bool IsExpired => lifetime >= maxLifetime;

        // Oyuncunun baktığı yöne göre orb pozisyonu
        private Farmer owner;

        public AkaOrb(Farmer player)
        {
            owner = player;
            offset = new Vector2(0, -forwardDistance);
        }

        public void Update(Farmer player)
        {
            lifetime += (float)Game1.currentGameTime.ElapsedGameTime.TotalSeconds;
            bobTimer += (float)Game1.currentGameTime.ElapsedGameTime.TotalSeconds;

            // Silah bırakıldıysa orb'u yok et
            if (player.CurrentItem == null || player.CurrentItem.Name != "Aka - Kırmızı")
            {
                lifetime = maxLifetime;
                return;
            }

            // Oyuncunun baktığı yöne göre orb'un önünde konumlan
            UpdateOrbPosition(player);
        }

        private void UpdateOrbPosition(Farmer player)
        {
            // Oyuncunun yönü (0=yukarı, 1=aşağı, 2=sol, 3=sağ)
            Vector2 forward = GetForwardDirection(player.FacingDirection);

            // Yukarı aşağı sallanma (sinüs dalgası)
            float bobOffset = (float)Math.Sin(bobTimer * bobSpeed) * bobAmount;

            // Orb'un hedef pozisyonu: oyuncunun önünde + sallanma
            Vector2 baseOffset = forward * forwardDistance;

            // Sallanma yönü ileri yönüne dik (yan sallanma değil, yukarı-aşağı)
            Vector2 upOffset = new Vector2(0, bobOffset);

            offset = baseOffset + upOffset;
        }

        private Vector2 GetForwardDirection(int facingDirection)
        {
            return facingDirection switch
            {
                0 => new Vector2(0, -1),  // Yukarı
                1 => new Vector2(0, 1),   // Aşağı
                2 => new Vector2(-1, 0),  // Sol
                3 => new Vector2(1, 0),   // Sağ
                _ => new Vector2(0, -1)
            };
        }

        public void Draw(SpriteBatch spriteBatch, Farmer player)
        {
            // Orb'un dünya pozisyonu
            Vector2 worldPos = player.Position + offset;

            // Dünya pozisyonunu ekran pozisyonuna çevir
            Vector2 screenPos = Game1.GlobalToLocal(Game1.viewport, worldPos);

            // Kırmızı orb texture'u çiz (senin çizdiğin resim)
            Texture2D orbTexture = GetAkaTexture();
            if (orbTexture == null) return;

            // Parlaklık efekti için alpha değişimi
            float alpha = 0.85f + (float)Math.Sin(bobTimer * 3f) * 0.15f;

            // Orb boyutu
            float scale = 2.5f;
            int size = (int)(orbTexture.Width * scale);

            Rectangle destRect = new Rectangle(
                (int)(screenPos.X - size / 2),
                (int)(screenPos.Y - size / 2),
                size,
                size
            );

            // Kırmızı renk tonu ile çiz
            Color drawColor = new Color(1f, 0.3f, 0.3f, alpha);

            spriteBatch.Draw(
                orbTexture,
                destRect,
                null,
                drawColor,
                0f,
                Vector2.Zero,
                SpriteEffects.None,
                0.9f
            );

            // Parıltı efekti (iç ışık)
            DrawGlowEffect(spriteBatch, screenPos, alpha);
        }

        private void DrawGlowEffect(SpriteBatch spriteBatch, Vector2 screenPos, float alpha)
        {
            // Beyaz iç parıltı
            Texture2D pixel = new Texture2D(Game1.graphics.GraphicsDevice, 1, 1);
            pixel.SetData(new[] { Color.White });

            float glowSize = 8f + (float)Math.Sin(bobTimer * 4f) * 3f;
            Color glowColor = new Color(1f, 0.5f, 0.5f, alpha * 0.4f);

            spriteBatch.Draw(
                pixel,
                new Rectangle(
                    (int)(screenPos.X - glowSize / 2),
                    (int)(screenPos.Y - glowSize / 2),
                    (int)glowSize,
                    (int)glowSize
                ),
                glowColor
            );
        }

        private Texture2D GetAkaTexture()
        {
            // Modun assets klasöründen Aka texture'unu yükle
            try
            {
                return Game1.content.Load<Texture2D>("Mods/CursedTechniques/aka_orb");
            }
            catch
            {
                return null;
            }
        }
    }
}
