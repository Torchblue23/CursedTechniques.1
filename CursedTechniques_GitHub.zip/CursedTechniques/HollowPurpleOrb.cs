using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using StardewValley;
using StardewValley.Monsters;
using System;
using System.Collections.Generic;

namespace CursedTechniques
{
    public enum HollowPurpleState
    {
        Charging,   // Şarj ediliyor
        Flying,     // Fırlatıldı, uçuyor
        Exploding,  // Patlama efekti
        Done        // Bitti
    }

    public class HollowPurpleOrb
    {
        // Durum
        public HollowPurpleState State = HollowPurpleState.Charging;
        public bool IsExpired => State == HollowPurpleState.Done;

        // Şarj
        private float chargeTime = 0f;
        private float maxChargeTime = 1.5f;   // 1.5 saniye tam şarj
        public float ChargePercent => Math.Min(chargeTime / maxChargeTime, 1f);

        // Uçuş
        private Vector2 position;
        private Vector2 velocity;
        private float speed = 12f;
        private float maxRange = 600f;
        private float traveledDistance = 0f;

        // Patlama
        private float explosionTimer = 0f;
        private float explosionDuration = 0.5f;
        private float explosionRadius = 150f;
        private Vector2 explosionPos;

        // Görsel
        private float bobTimer = 0f;
        private float glowPulse = 0f;

        // Şarj pozisyonu (oyuncunun önünde)
        private Vector2 chargeOffset;

        public HollowPurpleOrb() { }

        public void AddCharge(float delta)
        {
            if (State != HollowPurpleState.Charging) return;
            chargeTime += delta;
            bobTimer += delta;
            glowPulse += delta;
        }

        public void Launch(Farmer player)
        {
            if (State != HollowPurpleState.Charging) return;

            State = HollowPurpleState.Flying;

            // Oyuncunun baktığı yönde fırlat
            Vector2 dir = GetForwardDirection(player.FacingDirection);
            velocity = dir * speed;

            // Başlangıç pozisyonu: oyuncunun önünde
            position = player.Position + dir * 60f;
        }

        public void Update(Farmer player, GameLocation location)
        {
            bobTimer += (float)Game1.currentGameTime.ElapsedGameTime.TotalSeconds;
            glowPulse += (float)Game1.currentGameTime.ElapsedGameTime.TotalSeconds;

            if (State == HollowPurpleState.Charging)
            {
                // Şarj sırasında oyuncunun önünde dur
                Vector2 forward = GetForwardDirection(player.FacingDirection);
                float bob = (float)Math.Sin(bobTimer * 3f) * 8f;
                chargeOffset = forward * 70f + new Vector2(0, bob);
            }
            else if (State == HollowPurpleState.Flying)
            {
                position += velocity;
                traveledDistance += speed;

                // Düşmanlara çarptı mı kontrol et
                CheckHitEnemies(location);

                // Maksimum menzile ulaştıysa patlat
                if (traveledDistance >= maxRange)
                    StartExplosion(position);
            }
            else if (State == HollowPurpleState.Exploding)
            {
                explosionTimer += (float)Game1.currentGameTime.ElapsedGameTime.TotalSeconds;

                // Patlama alanındaki düşmanlara hasar ver
                DamageEnemiesInRadius(location);

                if (explosionTimer >= explosionDuration)
                    State = HollowPurpleState.Done;
            }
        }

        private void CheckHitEnemies(GameLocation location)
        {
            foreach (var character in location.characters)
            {
                if (character is Monster monster)
                {
                    float dist = Vector2.Distance(position, monster.Position);
                    if (dist < 40f)
                    {
                        StartExplosion(position);
                        return;
                    }
                }
            }
        }

        private void StartExplosion(Vector2 pos)
        {
            State = HollowPurpleState.Exploding;
            explosionPos = pos;
            explosionTimer = 0f;

            // Patlama sesi
            Game1.playSound("explosion");
        }

        private void DamageEnemiesInRadius(GameLocation location)
        {
            // Her frame değil, sadece başında hasar ver
            if (explosionTimer > 0.05f) return;

            foreach (var character in location.characters)
            {
                if (character is Monster monster)
                {
                    float dist = Vector2.Distance(explosionPos, monster.Position);
                    if (dist < explosionRadius)
                    {
                        // Uzaklığa göre hasar: yakın = daha fazla
                        float damageMult = 1f - (dist / explosionRadius);
                        int damage = (int)(80f * damageMult) + 40;

                        monster.takeDamage(damage, 0, 0, false, 1.0, Game1.player);

                        // Patlama merkezi ile itme
                        Vector2 knockDir = monster.Position - explosionPos;
                        if (knockDir != Vector2.Zero) knockDir.Normalize();
                        monster.Position += knockDir * 120f;
                    }
                }
            }
        }

        public void Draw(SpriteBatch spriteBatch, Farmer player)
        {
            if (State == HollowPurpleState.Charging)
                DrawCharging(spriteBatch, player);
            else if (State == HollowPurpleState.Flying)
                DrawFlying(spriteBatch);
            else if (State == HollowPurpleState.Exploding)
                DrawExplosion(spriteBatch);
        }

        private void DrawCharging(SpriteBatch spriteBatch, Farmer player)
        {
            Vector2 worldPos = player.Position + chargeOffset;
            Vector2 screenPos = Game1.GlobalToLocal(Game1.viewport, worldPos);

            Texture2D tex = GetTexture();
            if (tex == null) return;

            // Şarj yüzdesine göre boyut büyür
            float scale = 1.5f + ChargePercent * 2f;
            int size = (int)(tex.Width * scale);

            // Şarj olurken titreme
            float shake = (1f - ChargePercent) * 3f;
            screenPos += new Vector2(
                (float)(new Random().NextDouble() - 0.5) * shake,
                (float)(new Random().NextDouble() - 0.5) * shake
            );

            float alpha = 0.5f + ChargePercent * 0.5f;
            Color color = new Color(0.7f, 0.2f, 1f, alpha);

            spriteBatch.Draw(tex,
                new Rectangle((int)(screenPos.X - size / 2), (int)(screenPos.Y - size / 2), size, size),
                null, color, 0f, Vector2.Zero, SpriteEffects.None, 0.9f);

            // Şarj halkası efekti
            DrawChargeRing(spriteBatch, screenPos);
        }

        private void DrawChargeRing(SpriteBatch spriteBatch, Vector2 screenPos)
        {
            Texture2D pixel = new Texture2D(Game1.graphics.GraphicsDevice, 1, 1);
            pixel.SetData(new[] { Color.White });

            float ringSize = 20f + ChargePercent * 60f;
            float alpha = ChargePercent * 0.6f;
            Color ringColor = new Color(0.8f, 0.4f, 1f, alpha);

            // 4 köşede parlama noktaları
            for (int i = 0; i < 4; i++)
            {
                float angle = (float)(i * Math.PI / 2) + bobTimer * 2f;
                Vector2 offset = new Vector2(
                    (float)Math.Cos(angle) * ringSize,
                    (float)Math.Sin(angle) * ringSize
                );
                spriteBatch.Draw(pixel,
                    new Rectangle((int)(screenPos.X + offset.X - 3), (int)(screenPos.Y + offset.Y - 3), 6, 6),
                    ringColor);
            }
        }

        private void DrawFlying(SpriteBatch spriteBatch)
        {
            Vector2 screenPos = Game1.GlobalToLocal(Game1.viewport, position);
            Texture2D tex = GetTexture();
            if (tex == null) return;

            float scale = 3.5f;
            int size = (int)(tex.Width * scale);

            // Uçarken döner
            float rotation = bobTimer * 4f;
            Color color = new Color(0.7f, 0.2f, 1f, 1f);

            spriteBatch.Draw(tex,
                new Rectangle((int)(screenPos.X - size / 2), (int)(screenPos.Y - size / 2), size, size),
                null, color, rotation,
                new Vector2(tex.Width / 2f, tex.Height / 2f),
                SpriteEffects.None, 0.9f);
        }

        private void DrawExplosion(SpriteBatch spriteBatch)
        {
            Vector2 screenPos = Game1.GlobalToLocal(Game1.viewport, explosionPos);

            float progress = explosionTimer / explosionDuration;
            float currentRadius = explosionRadius * progress * Game1.options.zoomLevel;
            float alpha = 1f - progress;

            Texture2D pixel = new Texture2D(Game1.graphics.GraphicsDevice, 1, 1);
            pixel.SetData(new[] { Color.White });

            // Mor patlama dairesi
            Color explodeColor = new Color(0.7f, 0.1f, 1f, alpha);
            int r = (int)currentRadius;
            spriteBatch.Draw(pixel,
                new Rectangle((int)(screenPos.X - r), (int)(screenPos.Y - r), r * 2, r * 2),
                explodeColor);

            // İç beyaz parlama
            float innerR = r / 3;
            Color innerColor = new Color(1f, 0.8f, 1f, alpha * 0.8f);
            spriteBatch.Draw(pixel,
                new Rectangle((int)(screenPos.X - innerR), (int)(screenPos.Y - innerR), (int)(innerR * 2), (int)(innerR * 2)),
                innerColor);
        }

        private Vector2 GetForwardDirection(int facingDirection)
        {
            return facingDirection switch
            {
                0 => new Vector2(0, -1),
                1 => new Vector2(0, 1),
                2 => new Vector2(-1, 0),
                3 => new Vector2(1, 0),
                _ => new Vector2(0, -1)
            };
        }

        private Texture2D GetTexture()
        {
            try { return Game1.content.Load<Texture2D>("Mods/CursedTechniques/hollow_purple_orb"); }
            catch { return null; }
        }
    }
}
