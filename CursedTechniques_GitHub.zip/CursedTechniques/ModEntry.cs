using StardewModdingAPI;
using StardewModdingAPI.Events;
using StardewValley;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Input.Touch;
using System.Collections.Generic;

namespace CursedTechniques
{
    public class ModEntry : Mod
    {
        private List<AkaOrb> activeAkaOrbs = new List<AkaOrb>();
        private List<AoOrb> activeAoOrbs = new List<AoOrb>();
        private HollowPurpleOrb hollowPurple = null;
        private bool isChargingHP = false;

        // Mobil UI
        private MobileUI mobileUI;
        private bool isMobile => Constants.TargetPlatform == GamePlatform.Android
                              || Constants.TargetPlatform == GamePlatform.iOS;

        public override void Entry(IModHelper helper)
        {
            helper.Events.GameLoop.UpdateTicked += OnUpdateTicked;
            helper.Events.GameLoop.GameLaunched += OnGameLaunched;
            helper.Events.Display.RenderedHud += OnRenderedHud;
            helper.Events.Display.RenderedWorld += OnRenderedWorld;
            helper.Events.Display.WindowResized += OnWindowResized;

            // Klavye/gamepad (PC)
            helper.Events.Input.ButtonPressed += OnButtonPressed;
            helper.Events.Input.ButtonReleased += OnButtonReleased;

            Monitor.Log($"Cursed Techniques yüklendi! Platform: {Constants.TargetPlatform}", LogLevel.Info);
        }

        private void OnGameLaunched(object sender, GameLaunchedEventArgs e)
        {
            mobileUI = new MobileUI();

            // Mobil UI olaylarını bağla
            mobileUI.OnAkaTapped += () => ActivateAka(Game1.player);
            mobileUI.OnAoTapped += () => ActivateAo(Game1.player);
            mobileUI.OnHPHoldStart += () =>
            {
                hollowPurple = new HollowPurpleOrb();
                isChargingHP = true;
                Game1.playSound("secret1");
            };
            mobileUI.OnHPHoldRelease += () =>
            {
                if (hollowPurple != null && isChargingHP)
                {
                    isChargingHP = false;
                    hollowPurple.Launch(Game1.player);
                    Game1.playSound("thunder");
                }
            };
        }

        private void OnWindowResized(object sender, WindowResizedEventArgs e)
        {
            mobileUI?.RecalculatePositions();
        }

        // ── PC Klavye Kontrolü ──────────────────────────────────────

        private void OnButtonPressed(object sender, ButtonPressedEventArgs e)
        {
            if (!Context.IsWorldReady || isMobile) return;

            var player = Game1.player;
            var heldItem = player.CurrentItem;
            if (heldItem == null) return;

            if (e.Button == SButton.R)
            {
                if (heldItem.Name == "Aka - Kırmızı") ActivateAka(player);
                if (heldItem.Name == "Ao - Mavi") ActivateAo(player);
                if (heldItem.Name == "Hollow Purple")
                {
                    hollowPurple = new HollowPurpleOrb();
                    isChargingHP = true;
                    Game1.playSound("secret1");
                }
            }
        }

        private void OnButtonReleased(object sender, ButtonReleasedEventArgs e)
        {
            if (!Context.IsWorldReady || isMobile) return;

            if (e.Button == SButton.R && isChargingHP && hollowPurple != null)
            {
                isChargingHP = false;
                hollowPurple.Launch(Game1.player);
                Game1.playSound("thunder");
            }
        }

        // ── Dokunmatik Giriş ────────────────────────────────────────

        private void HandleTouchInput()
        {
            if (!isMobile || mobileUI == null) return;

            var touchState = TouchPanel.GetState();

            foreach (var touch in touchState)
            {
                // UI koordinatına çevir
                int uiX = (int)(touch.Position.X / Game1.options.zoomLevel);
                int uiY = (int)(touch.Position.Y / Game1.options.zoomLevel);

                if (touch.State == TouchLocationState.Pressed)
                    mobileUI.HandleTouchDown(uiX, uiY);

                if (touch.State == TouchLocationState.Released)
                    mobileUI.HandleTouchUp(uiX, uiY);
            }
        }

        // ── Silah Aktivasyon Fonksiyonları ──────────────────────────

        private void ActivateAka(Farmer player)
        {
            activeAkaOrbs.Add(new AkaOrb(player));
            Monitor.Log("Aka aktif!", LogLevel.Debug);
        }

        private void ActivateAo(Farmer player)
        {
            activeAoOrbs.Add(new AoOrb(player));
            Monitor.Log("Ao aktif!", LogLevel.Debug);
        }

        // ── Update ──────────────────────────────────────────────────

        private void OnUpdateTicked(object sender, UpdateTickedEventArgs e)
        {
            if (!Context.IsWorldReady) return;

            var player = Game1.player;
            var location = player.currentLocation;
            float delta = (float)Game1.currentGameTime.ElapsedGameTime.TotalSeconds;

            // Dokunmatik girişi işle
            HandleTouchInput();

            // Mobil UI güncelle
            string weaponName = player.CurrentItem?.Name ?? "";
            mobileUI?.Update(delta, weaponName);

            // Aka
            for (int i = activeAkaOrbs.Count - 1; i >= 0; i--)
            {
                activeAkaOrbs[i].Update(player);
                if (activeAkaOrbs[i].IsExpired) activeAkaOrbs.RemoveAt(i);
            }
            if (activeAkaOrbs.Count > 0) PushEnemies(player);

            // Ao
            for (int i = activeAoOrbs.Count - 1; i >= 0; i--)
            {
                activeAoOrbs[i].Update(player);
                if (activeAoOrbs[i].IsExpired) activeAoOrbs.RemoveAt(i);
            }
            if (activeAoOrbs.Count > 0) PullEnemies(player);

            // Hollow Purple
            if (hollowPurple != null)
            {
                if (isChargingHP)
                    hollowPurple.AddCharge(delta);
                else
                    hollowPurple.Update(player, location);

                if (hollowPurple.IsExpired)
                    hollowPurple = null;
            }
        }

        // ── Düşman Efektleri ────────────────────────────────────────

        private void PushEnemies(Farmer player)
        {
            var location = player.currentLocation;
            if (location == null) return;

            foreach (var character in location.characters)
            {
                if (character is StardewValley.Monsters.Monster monster)
                {
                    float distance = Vector2.Distance(player.Position, monster.Position);
                    if (distance < 300f && distance > 20f)
                    {
                        Vector2 direction = monster.Position - player.Position;
                        direction.Normalize();
                        monster.Position += direction * ((300f - distance) / 300f * 5f);
                    }
                }
            }
        }

        private void PullEnemies(Farmer player)
        {
            var location = player.currentLocation;
            if (location == null) return;

            foreach (var character in location.characters)
            {
                if (character is StardewValley.Monsters.Monster monster)
                {
                    float distance = Vector2.Distance(player.Position, monster.Position);
                    if (distance < 300f && distance > 20f)
                    {
                        Vector2 direction = player.Position - monster.Position;
                        direction.Normalize();
                        monster.Position += direction * ((300f - distance) / 300f * 3.5f);
                    }
                }
            }
        }

        // ── Çizim ───────────────────────────────────────────────────

        private void OnRenderedWorld(object sender, RenderedWorldEventArgs e)
        {
            if (!Context.IsWorldReady) return;

            foreach (var orb in activeAkaOrbs)
                orb.Draw(e.SpriteBatch, Game1.player);

            foreach (var orb in activeAoOrbs)
                orb.Draw(e.SpriteBatch, Game1.player);

            hollowPurple?.Draw(e.SpriteBatch, Game1.player);
        }

        private void OnRenderedHud(object sender, RenderedHudEventArgs e)
        {
            if (!Context.IsWorldReady || !isMobile) return;

            // Mobil butonları HUD'un üstüne çiz
            mobileUI?.Draw(e.SpriteBatch);
        }
    }
}
