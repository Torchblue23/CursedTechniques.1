using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using StardewValley;
using StardewValley.Menus;
using System;

namespace CursedTechniques
{
    /// <summary>
    /// Mobil için ekranda görünen dokunmatik butonlar.
    /// Aka, Ao ve Hollow Purple için ayrı butonlar sağ alt köşede çıkar.
    /// </summary>
    public class MobileUI
    {
        // Buton boyutları
        private const int ButtonSize = 80;
        private const int ButtonPadding = 12;
        private const int EdgePadding = 20;

        // Buton pozisyonları (sağ alt köşe)
        private Rectangle akaButton;
        private Rectangle aoButton;
        private Rectangle hollowPurpleButton;

        // Hollow Purple basılı tutma takibi
        public bool IsHoldingHP { get; private set; } = false;
        private float hpHoldTime = 0f;

        // Olaylar — ModEntry bunları dinler
        public event Action OnAkaTapped;
        public event Action OnAoTapped;
        public event Action OnHPHoldStart;
        public event Action OnHPHoldRelease;

        // Aktif silah
        private string currentWeapon = "";

        public MobileUI()
        {
            RecalculatePositions();
        }

        public void RecalculatePositions()
        {
            int screenW = Game1.uiViewport.Width;
            int screenH = Game1.uiViewport.Height;

            // Sağ alt köşe — üst üste dizili 3 buton
            int x = screenW - ButtonSize - EdgePadding;

            hollowPurpleButton = new Rectangle(
                x,
                screenH - ButtonSize - EdgePadding,
                ButtonSize, ButtonSize
            );
            aoButton = new Rectangle(
                x,
                screenH - (ButtonSize + ButtonPadding) * 2 - EdgePadding,
                ButtonSize, ButtonSize
            );
            akaButton = new Rectangle(
                x,
                screenH - (ButtonSize + ButtonPadding) * 3 - EdgePadding,
                ButtonSize, ButtonSize
            );
        }

        public void Update(float delta, string weaponName)
        {
            currentWeapon = weaponName;

            if (IsHoldingHP)
            {
                hpHoldTime += delta;
            }
        }

        /// <summary>
        /// Dokunma koordinatı gelince çağrılır (UI koordinatı).
        /// </summary>
        public void HandleTouchDown(int x, int y)
        {
            if (!IsWeaponActive()) return;

            if (currentWeapon == "Aka - Kırmızı" && akaButton.Contains(x, y))
            {
                OnAkaTapped?.Invoke();
                Game1.playSound("dwop");
            }
            else if (currentWeapon == "Ao - Mavi" && aoButton.Contains(x, y))
            {
                OnAoTapped?.Invoke();
                Game1.playSound("dwop");
            }
            else if (currentWeapon == "Hollow Purple" && hollowPurpleButton.Contains(x, y))
            {
                IsHoldingHP = true;
                hpHoldTime = 0f;
                OnHPHoldStart?.Invoke();
            }
        }

        public void HandleTouchUp(int x, int y)
        {
            if (IsHoldingHP)
            {
                IsHoldingHP = false;
                OnHPHoldRelease?.Invoke();
            }
        }

        private bool IsWeaponActive()
        {
            return currentWeapon == "Aka - Kırmızı"
                || currentWeapon == "Ao - Mavi"
                || currentWeapon == "Hollow Purple";
        }

        public void Draw(SpriteBatch spriteBatch)
        {
            if (!IsWeaponActive()) return;

            // Her silah için ilgili butonu çiz
            if (currentWeapon == "Aka - Kırmızı")
                DrawButton(spriteBatch, akaButton, new Color(1f, 0.2f, 0.2f, 0.85f), "赤", "AKA");

            if (currentWeapon == "Ao - Mavi")
                DrawButton(spriteBatch, aoButton, new Color(0.2f, 0.5f, 1f, 0.85f), "蒼", "AO");

            if (currentWeapon == "Hollow Purple")
            {
                // HP butonu — şarj yüzdesine göre dolum animasyonu
                float chargePercent = Math.Min(hpHoldTime / 1.5f, 1f);
                DrawHollowPurpleButton(spriteBatch, hollowPurpleButton, chargePercent);
            }
        }

        private void DrawButton(SpriteBatch spriteBatch, Rectangle rect, Color color, string kanji, string label)
        {
            Texture2D pixel = new Texture2D(Game1.graphics.GraphicsDevice, 1, 1);
            pixel.SetData(new[] { Color.White });

            // Arka plan
            spriteBatch.Draw(pixel, rect, color * 0.7f);

            // Kenar
            DrawBorder(spriteBatch, pixel, rect, color, 3);

            // Kanji yazısı
            DrawCenteredText(spriteBatch, kanji, rect, Color.White, 1.2f);
        }

        private void DrawHollowPurpleButton(SpriteBatch spriteBatch, Rectangle rect, float chargePercent)
        {
            Texture2D pixel = new Texture2D(Game1.graphics.GraphicsDevice, 1, 1);
            pixel.SetData(new[] { Color.White });

            Color baseColor = new Color(0.6f, 0.1f, 1f, 0.85f);

            // Arka plan
            spriteBatch.Draw(pixel, rect, baseColor * 0.7f);

            // Şarj dolum çubuğu (aşağıdan yukarı dolar)
            if (chargePercent > 0f)
            {
                int fillH = (int)(rect.Height * chargePercent);
                Rectangle fillRect = new Rectangle(
                    rect.X, rect.Y + rect.Height - fillH,
                    rect.Width, fillH
                );
                Color fillColor = new Color(0.9f, 0.5f, 1f, 0.6f);
                spriteBatch.Draw(pixel, fillRect, fillColor);
            }

            // Kenar (tam şarjda parlak)
            Color borderColor = chargePercent >= 1f
                ? new Color(1f, 0.9f, 1f, 1f)
                : new Color(0.7f, 0.3f, 1f, 1f);
            DrawBorder(spriteBatch, pixel, rect, borderColor, chargePercent >= 1f ? 4 : 2);

            // Yazı
            string label = chargePercent >= 1f ? "✦" : "茈";
            DrawCenteredText(spriteBatch, label, rect, Color.White, 1.2f);

            // Tam şarjda titreşim efekti için ekstra parlama
            if (chargePercent >= 1f)
            {
                Rectangle glowRect = new Rectangle(rect.X - 4, rect.Y - 4, rect.Width + 8, rect.Height + 8);
                spriteBatch.Draw(pixel, glowRect, new Color(0.8f, 0.4f, 1f, 0.3f));
            }
        }

        private void DrawBorder(SpriteBatch spriteBatch, Texture2D pixel, Rectangle rect, Color color, int thickness)
        {
            // Üst
            spriteBatch.Draw(pixel, new Rectangle(rect.X, rect.Y, rect.Width, thickness), color);
            // Alt
            spriteBatch.Draw(pixel, new Rectangle(rect.X, rect.Bottom - thickness, rect.Width, thickness), color);
            // Sol
            spriteBatch.Draw(pixel, new Rectangle(rect.X, rect.Y, thickness, rect.Height), color);
            // Sağ
            spriteBatch.Draw(pixel, new Rectangle(rect.Right - thickness, rect.Y, thickness, rect.Height), color);
        }

        private void DrawCenteredText(SpriteBatch spriteBatch, string text, Rectangle rect, Color color, float scale)
        {
            var font = Game1.smallFont;
            Vector2 textSize = font.MeasureString(text) * scale;
            Vector2 pos = new Vector2(
                rect.X + (rect.Width - textSize.X) / 2f,
                rect.Y + (rect.Height - textSize.Y) / 2f
            );
            spriteBatch.DrawString(font, text, pos, color, 0f, Vector2.Zero, scale, SpriteEffects.None, 1f);
        }
    }
}
