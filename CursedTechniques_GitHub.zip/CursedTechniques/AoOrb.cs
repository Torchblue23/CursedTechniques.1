using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using StardewValley;
using System;

namespace CursedTechniques
{
    public class AoOrb
    {
        private Vector2 offset;
        private float bobTimer = 0f;
        private float bobAmount = 12f;
        private float bobSpeed = 2.5f;
        private float lifetime = 0f;
        private float maxLifetime = 999f;
        private float forwardDistance = 80f;

        public bool IsExpired => lifetime >= maxLifetime;

        public AoOrb(Farmer player) { }

        public void Update(Farmer player)
        {
            lifetime += (float)Game1.currentGameTime.ElapsedGameTime.TotalSeconds;
            bobTimer += (float)Game1.currentGameTime.ElapsedGameTime.TotalSeconds;

            if (player.CurrentItem == null || player.CurrentItem.Name != "Ao - Mavi")
            {
                lifetime = maxLifetime;
                return;
            }

            UpdateOrbPosition(player);
        }

        private void UpdateOrbPosition(Farmer player)
        {
            Vector2 forward = GetForwardDirection(player.FacingDirection);
            float bobOffset = (float)Math.Sin(bobTimer * bobSpeed) * bobAmount;
            Vector2 baseOffset = forward * forwardDistance;
            Vector2 upOffset = new Vector2(0, bobOffset);
            offset = baseOffset + upOffset;
        }

        private Vector2 GetForwardDirection(int facingDirection)
        {
            return facingDirection switch
            {
                0 => new Vector2(0, -1),
                1 => new Vector2(0, 1),
                2 => new Vector2(-1, 0),
                3 => new Vector2(1, 0),
                _ => new Vector2(0, -1)
            };
        }

        public void Draw(SpriteBatch spriteBatch, Farmer player)
        {
            Vector2 worldPos = player.Position + offset;
            Vector2 screenPos = Game1.GlobalToLocal(Game1.viewport, worldPos);

            Texture2D orbTexture = GetAoTexture();
            if (orbTexture == null) return;

            float alpha = 0.85f + (float)Math.Sin(bobTimer * 3f) * 0.15f;
            float scale = 2.5f;
            int size = (int)(orbTexture.Width * scale);

            Rectangle destRect = new Rectangle(
                (int)(screenPos.X - size / 2),
                (int)(screenPos.Y - size / 2),
                size, size
            );

            Color drawColor = new Color(0.3f, 0.5f, 1f, alpha);
            spriteBatch.Draw(orbTexture, destRect, null, drawColor, 0f, Vector2.Zero, SpriteEffects.None, 0.9f);
            DrawGlowEffect(spriteBatch, screenPos, alpha);
        }

        private void DrawGlowEffect(SpriteBatch spriteBatch, Vector2 screenPos, float alpha)
        {
            Texture2D pixel = new Texture2D(Game1.graphics.GraphicsDevice, 1, 1);
            pixel.SetData(new[] { Color.White });

            float glowSize = 8f + (float)Math.Sin(bobTimer * 4f) * 3f;
            Color glowColor = new Color(0.3f, 0.7f, 1f, alpha * 0.4f);

            spriteBatch.Draw(pixel, new Rectangle(
                (int)(screenPos.X - glowSize / 2),
                (int)(screenPos.Y - glowSize / 2),
                (int)glowSize, (int)glowSize
            ), glowColor);
        }

        private Texture2D GetAoTexture()
        {
            try { return Game1.content.Load<Texture2D>("Mods/CursedTechniques/ao_orb"); }
            catch { return null; }
        }
    }
}
