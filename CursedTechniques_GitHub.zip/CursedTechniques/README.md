# 赤 Cursed Techniques — JJK Mod

Jujutsu Kaisen'den lanetli teknikler Stardew Valley'e geliyor!

---

## 📦 Kurulum

### Gerekenler
- Stardew Valley (1.6+)
- [SMAPI](https://smapi.io/) — Mod yükleyici
- [Content Patcher](https://www.nexusmods.com/stardewvalley/mods/1915) — İçerik değiştirici

### Adımlar
1. SMAPI'yi kur
2. Content Patcher'ı `Mods` klasörüne at
3. Bu klasörü `Mods` klasörüne at:
   ```
   Stardew Valley/
   └── Mods/
       └── CursedTechniques/
           ├── manifest.json
           ├── content.json
           ├── CursedTechniques.dll  ← derlendikten sonra
           └── assets/
               ├── aka_orb.png       ← senin kırmızı çizimin (16x16 veya 32x32)
               └── weapons.png       ← silah sprite sheet
   ```

### Görseller için
`assets/` klasörüne koy:
- `aka_orb.png` → Kırmızı spiral top görselin (senin çizimin!)
- `weapons.png` → 16x16 boyutunda silah ikonu

---

## ⚔️ Silah: 赤 Aka — Kırmızı

| Özellik | Değer |
|--------|-------|
| Tip | Club (Topuz) |
| Min Hasar | 25 |
| Max Hasar | 45 |
| Knockback | +3 (itme!) |
| Hız | +2 |
| Kritik Şans | %8 |
| Fiyat | 15,000 altın |

**Nerede bulunur?** → Adventure Guild (Macera Loncası)

---

## 🎮 Nasıl Kullanılır?

1. Aka'yı eline al
2. **[R]** tuşuna bas → Kırmızı orb önünde belirir ve yukarı aşağı sallanır
3. Otomatik olarak 300px çevresindeki düşmanları sana doğru çeker
4. Silahı bırakınca orb kaybolur

---

## 🔜 Yakında

- 🔵 **Ao (Mavi)** — İtme gücü
- 🟣 **Hollow Purple** — İkisinin birleşimi, AoE imha

---

*"Throughout Heaven and Earth, I alone am the honored one."*
